#!/usr/bin/env bash
# تشغيل اللوحة: ./start.sh   (أو ADMIN_PASS='...' ./start.sh)
cd "$(dirname "$0")"
[ -d node_modules ] || npm install
command -v termux-wake-lock >/dev/null && termux-wake-lock
export ADMIN_USER="${ADMIN_USER:-admin}"
if [ -z "$ADMIN_PASS" ]; then read -rp "اختر كلمة مرور للوحة: " ADMIN_PASS; export ADMIN_PASS; fi
exec node server.js

#!/usr/bin/env bash
# رفع المشروع على GitHub: ./publish.sh https://github.com/USER/REPO.git
# عند طلب كلمة المرور استخدم Personal Access Token من GitHub
[ -z "$1" ] && { echo "الاستخدام: ./publish.sh <رابط-الريبو>"; exit 1; }
git init -q && git add . && git commit -qm "BotHost" && git branch -M main
git remote remove origin 2>/dev/null; git remote add origin "$1" && git push -u origin main

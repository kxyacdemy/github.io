const express=require('express'),session=require('express-session'),multer=require('multer'),AdmZip=require('adm-zip'),pidusage=require('pidusage');
const {spawn,exec}=require('child_process'),fs=require('fs'),path=require('path'),os=require('os'),crypto=require('crypto');
const PORT=process.env.PORT||3000,USER=process.env.ADMIN_USER||'admin',PASS=process.env.ADMIN_PASS||'admin123';
const DATA=path.join(__dirname,'data'),BOTS=path.join(DATA,'bots'),TMP=path.join(DATA,'tmp'),DB=path.join(DATA,'bots.json');
[BOTS,TMP].forEach(d=>fs.mkdirSync(d,{recursive:true}));
let bots={};try{bots=JSON.parse(fs.readFileSync(DB))}catch{}
const save=()=>fs.writeFileSync(DB,JSON.stringify(bots,null,2));
const procs={},logs={},subs={},sizes={},sleep=ms=>new Promise(r=>setTimeout(r,ms));
const dirOf=id=>path.join(BOTS,id);
function safe(id,p){const base=dirOf(id),t=path.resolve(path.join(base,p||''));if(t!==base&&!t.startsWith(base+path.sep))throw new Error('مسار غير صالح');return t}
function log(id,t){t=String(t).replace(/\x1b\[[0-9;]*[A-Za-z]/g,'');(logs[id]=logs[id]||[]).push(t);if(logs[id].length>1000)logs[id].shift();(subs[id]||new Set()).forEach(r=>r.write('data: '+JSON.stringify(t)+'\n\n'))}
function envOf(id){const o={};try{fs.readFileSync(path.join(dirOf(id),'.env'),'utf8').split('\n').forEach(l=>{const m=l.match(/^\s*([\w.]+)\s*=\s*(.*?)\s*$/);if(m)o[m[1]]=m[2].replace(/^["']|["']$/g,'')})}catch{}return o}
function start(id){const b=bots[id];if(!b||procs[id])return;b.stopped=false;save();
  const env={...process.env,...envOf(id)};if(b.ram)env.NODE_OPTIONS=`--max-old-space-size=${b.ram}`;
  const [cmd,...args]=b.start.trim().split(/\s+/);let p;
  try{p=spawn(cmd,args,{cwd:dirOf(id),env,detached:true,shell:process.platform==='win32'})}catch(e){return log(id,'فشل التشغيل: '+e.message+'\n')}
  procs[id]={p,at:Date.now()};log(id,`\n▶ تشغيل: ${b.start}\n`);
  p.stdout.on('data',d=>log(id,d));p.stderr.on('data',d=>log(id,d));
  p.on('error',e=>{log(id,'خطأ: '+e.message+'\n')});
  p.on('exit',c=>{if(procs[id]&&procs[id].p===p)delete procs[id];log(id,`\n■ توقف (code ${c})\n`);if(bots[id]&&bots[id].auto&&!bots[id].stopped)setTimeout(()=>start(id),3000)})}
function kill(id,sig){const x=procs[id];if(!x)return;try{process.kill(-x.p.pid,sig)}catch{try{x.p.kill(sig)}catch{}}}
function stop(id,manual=true){if(bots[id]&&manual){bots[id].stopped=true;save()}kill(id,'SIGTERM')}
async function restart(id){stop(id);for(let i=0;i<30&&procs[id];i++)await sleep(100);if(procs[id]){kill(id,'SIGKILL');await sleep(300)}start(id)}
function install(id){return new Promise(r=>{const d=dirOf(id),py=fs.existsSync(path.join(d,'requirements.txt'))&&!fs.existsSync(path.join(d,'package.json'));
  const cmd=py?'pip3 install -r requirements.txt':'npm install --omit=dev --no-audit --no-fund';log(id,`\n📦 ${cmd}\n`);
  const c=exec(cmd,{cwd:d,maxBuffer:1e9});c.stdout.on('data',x=>log(id,x));c.stderr.on('data',x=>log(id,x));c.on('exit',k=>{log(id,`\n📦 انتهى (code ${k})\n`);r()})})}
function mk(name,cmd){const id=crypto.randomBytes(4).toString('hex');bots[id]={id,name:(name||'bot').slice(0,60),start:cmd||'node index.js',ram:0,auto:true,created:Date.now()};fs.mkdirSync(dirOf(id),{recursive:true});save();return bots[id]}
function flatten(d){const e=fs.readdirSync(d).filter(x=>x!=='__MACOSX');if(e.length===1&&fs.statSync(path.join(d,e[0])).isDirectory()){const s=path.join(d,e[0]);fs.readdirSync(s).forEach(f=>fs.renameSync(path.join(s,f),path.join(d,f)));fs.rmdirSync(s)}}
function detect(id){const d=dirOf(id);try{const k=JSON.parse(fs.readFileSync(path.join(d,'package.json')));if(k.scripts&&k.scripts.start)return'npm start';if(k.main)return'node '+k.main}catch{}
  for(const f of['main.py','bot.py','app.py'])if(fs.existsSync(path.join(d,f)))return'python3 '+f;return'node index.js'}
function size(d){let t=0;try{for(const e of fs.readdirSync(d,{withFileTypes:true})){const p=path.join(d,e.name);t+=e.isDirectory()?size(p):e.isFile()?fs.statSync(p).size:0}}catch{}return t}
function usage(pid){return new Promise(r=>exec('ps -eo pgid=,rss=,pcpu=',(e,o)=>{if(!e){let m=0,c=0;o.split('\n').forEach(l=>{const t=l.trim().split(/\s+/);if(+t[0]===pid){m+=+t[1]*1024;c+=+t[2]}});if(m)return r({mem:m,cpu:c})}pidusage(pid).then(u=>r({mem:u.memory,cpu:u.cpu}),()=>r({mem:0,cpu:0}))}))}

const up=multer({dest:TMP}),app=express();
app.set('view engine','ejs');
app.use(express.urlencoded({extended:true,limit:'50mb'}),express.json({limit:'50mb'}),express.static(path.join(__dirname,'public')));
app.use(session({secret:process.env.SESSION_SECRET||crypto.createHash('sha256').update(PASS+__dirname).digest('hex'),resave:false,saveUninitialized:false,cookie:{maxAge:7*864e5,httpOnly:true,sameSite:'lax'}}));
const eq=(a,b)=>{const x=Buffer.from(String(a)),y=Buffer.from(String(b));return x.length===y.length&&crypto.timingSafeEqual(x,y)};
let fails={};
app.get('/login',(q,s)=>s.render('login',{err:null}));
app.post('/login',(q,s)=>{const ip=q.ip,f=fails[ip]||{n:0,t:0};if(f.n>=8&&Date.now()-f.t<9e5)return s.render('login',{err:'محاولات كثيرة، حاول بعد 15 دقيقة'});
  if(eq(q.body.u,USER)&&eq(q.body.p,PASS)){delete fails[ip];q.session.ok=1;return s.redirect('/')}
  fails[ip]={n:f.n+1,t:Date.now()};s.render('login',{err:'بيانات الدخول خاطئة'})});
app.get('/logout',(q,s)=>q.session.destroy(()=>s.redirect('/login')));
app.use((q,s,n)=>q.session.ok?n():(q.path.startsWith('/api')?s.status(401).json({error:'auth'}):s.redirect('/login')));
app.param('id',(q,s,n,id)=>bots[id]?n():s.status(404).send('البوت غير موجود'));

app.get('/',(q,s)=>s.render('dashboard',{bots:Object.values(bots).map(b=>({...b,running:!!procs[b.id]}))}));
app.get('/api/system',(q,s)=>{let disk={};try{const f=fs.statfsSync(DATA);disk={total:f.blocks*f.bsize,free:f.bavail*f.bsize}}catch{}
  s.json({mem:{total:os.totalmem(),free:os.freemem()},load:os.loadavg()[0],cpus:os.cpus().length,disk,running:Object.keys(procs).length,total:Object.keys(bots).length})});
app.post('/bots/create',(q,s)=>s.redirect('/bots/'+mk(q.body.name,q.body.start).id));
app.post('/bots/upload',up.single('zip'),(q,s)=>{if(!q.file)return s.redirect('/');
  const b=mk(q.body.name||q.file.originalname.replace(/\.zip$/i,''),''),d=dirOf(b.id);
  try{new AdmZip(q.file.path).extractAllTo(d,true);flatten(d)}catch(e){log(b.id,'خطأ في فك الضغط: '+e.message+'\n')}
  fs.unlink(q.file.path,()=>{});b.start=(q.body.start||'').trim()||detect(b.id);save();s.redirect('/bots/'+b.id);
  install(b.id).then(()=>{if(q.body.run)start(b.id)})});
app.get('/bots/:id',(q,s)=>s.render('bot',{b:bots[q.params.id],running:!!procs[q.params.id]}));
app.post('/bots/:id/:act',async(q,s)=>{const{id,act}=q.params,b=bots[id];
  if(act==='start')start(id);else if(act==='stop')stop(id);else if(act==='restart')await restart(id);else if(act==='install')install(id);
  else if(act==='delete'){stop(id);for(let i=0;i<20&&procs[id];i++)await sleep(100);kill(id,'SIGKILL');delete bots[id];save();fs.rmSync(dirOf(id),{recursive:true,force:true});delete logs[id];return s.redirect('/')}
  else if(act==='settings'){Object.assign(b,{name:(q.body.name||b.name).slice(0,60),start:(q.body.start||b.start).trim(),ram:Math.max(0,+q.body.ram||0),auto:!!q.body.auto});save()}
  else if(act==='cmd'){if(procs[id])procs[id].p.stdin.write(q.body.cmd+'\n');return s.end()}
  s.redirect('/bots/'+id)});

app.get('/api/bots/:id/logs',(q,s)=>{const id=q.params.id;s.set({'Content-Type':'text/event-stream','Cache-Control':'no-cache',Connection:'keep-alive'});s.flushHeaders();
  s.write('data: '+JSON.stringify((logs[id]||[]).join(''))+'\n\n');(subs[id]=subs[id]||new Set()).add(s);
  const hb=setInterval(()=>s.write(': ping\n\n'),20000);q.on('close',()=>{clearInterval(hb);subs[id].delete(s)})});
app.get('/api/bots/:id/stats',async(q,s)=>{const id=q.params.id,x=procs[id];
  if(!sizes[id]||Date.now()-sizes[id].t>20000)sizes[id]={t:Date.now(),v:size(dirOf(id))};
  const o={running:!!x,disk:sizes[id].v,mem:0,cpu:0,uptime:0};if(x){Object.assign(o,await usage(x.p.pid));o.uptime=Date.now()-x.at}s.json(o)});
const E=(s,e)=>s.status(400).json({error:e.message});
app.get('/api/bots/:id/files',(q,s)=>{try{const d=safe(q.params.id,q.query.p);s.json(fs.readdirSync(d,{withFileTypes:true}).map(e=>({n:e.name,d:e.isDirectory(),s:e.isFile()?fs.statSync(path.join(d,e.name)).size:0})).sort((a,b)=>b.d-a.d||a.n.localeCompare(b.n)))}catch(e){E(s,e)}});
app.get('/api/bots/:id/file',(q,s)=>{try{const f=safe(q.params.id,q.query.p);if(fs.statSync(f).size>3e6)return s.status(413).json({error:'الملف كبير للتعديل، حمّله بدلاً من ذلك'});s.json({c:fs.readFileSync(f,'utf8')})}catch(e){E(s,e)}});
app.post('/api/bots/:id/file',(q,s)=>{try{const f=safe(q.params.id,q.body.p);fs.mkdirSync(path.dirname(f),{recursive:true});fs.writeFileSync(f,q.body.c||'');s.json({ok:1})}catch(e){E(s,e)}});
app.post('/api/bots/:id/mkdir',(q,s)=>{try{fs.mkdirSync(safe(q.params.id,q.body.p),{recursive:true});s.json({ok:1})}catch(e){E(s,e)}});
app.post('/api/bots/:id/delete',(q,s)=>{try{const f=safe(q.params.id,q.body.p);if(f===dirOf(q.params.id))throw new Error('لا يمكن حذف المجلد الرئيسي');fs.rmSync(f,{recursive:true,force:true});s.json({ok:1})}catch(e){E(s,e)}});
app.post('/api/bots/:id/upload',up.array('f'),(q,s)=>{try{const d=safe(q.params.id,q.body.p);fs.mkdirSync(d,{recursive:true});
  (q.files||[]).forEach(f=>{const t=safe(q.params.id,path.join(q.body.p||'',path.basename(f.originalname)));fs.copyFileSync(f.path,t);fs.unlinkSync(f.path);
    if(/\.zip$/i.test(t)&&q.body.unzip==='1'){new AdmZip(t).extractAllTo(d,true);fs.unlinkSync(t)}});s.json({ok:1})}catch(e){E(s,e)}});
app.get('/api/bots/:id/download',(q,s)=>{try{s.download(safe(q.params.id,q.query.p))}catch(e){E(s,e)}});

Object.values(bots).forEach(b=>{if(b.auto&&!b.stopped)start(b.id)});
const bye=()=>{Object.keys(procs).forEach(id=>stop(id,false));setTimeout(()=>process.exit(),500)};
process.on('SIGINT',bye);process.on('SIGTERM',bye);process.on('uncaughtException',e=>console.error(e));
app.listen(PORT,'0.0.0.0',()=>console.log(`BotHost يعمل على http://localhost:${PORT}  (${USER} / ${PASS==='admin123'?'admin123 — غيّرها!':'***'})`));

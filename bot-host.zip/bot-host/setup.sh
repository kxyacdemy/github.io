#!/usr/bin/env bash
# تجهيز Termux: ./setup.sh
set -e
pkg update -y && pkg install -y nodejs python git unzip
npm install
chmod +x start.sh
echo "تم. شغّل اللوحة بـ: ./start.sh"

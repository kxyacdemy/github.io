# BotHost
لوحة استضافة بوتات (Node.js / Python): رفع ZIP، تشغيل/إيقاف، كونسول مباشر، مدير ملفات، مراقبة الرام والمعالج، إعادة تشغيل تلقائي، بدون حدود.

## Termux
    git clone <رابط-الريبو> && cd <المجلد>
    ./setup.sh
    ./start.sh          # يسألك عن كلمة المرور، ثم افتح http://localhost:3000
للإنترنت: pkg install cloudflared ثم cloudflared tunnel --url http://localhost:3000

## VPS
    npm install
    ADMIN_PASS='...' pm2 start server.js --name bothost && pm2 save && pm2 startup

المستخدم الافتراضي: admin (يمكن تغييره بـ ADMIN_USER). لا ترفع مجلد data/ (موجود في .gitignore).
